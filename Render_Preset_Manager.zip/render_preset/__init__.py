bl_info = {
    "name": "render_preset",
    "author": "Zekeriya AYAN",
    "version": (2, 5, 0),
    "blender": (4, 5, 0),
    "location": "Render Properties > Presets",
    "description": "Save current render settings into standalone .blend files and re-apply from a designated presets folder via an in-panel browser (Cycles & Eevee). No objects/collections are touched.",
    "category": "Render",
}

from . import render_preset


def register():
    render_preset.register()


def unregister():
    render_preset.unregister()
